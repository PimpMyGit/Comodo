# Comodo
IL comodo



How to import

Store main dir as 'C:\Users\<user>\AppData\Local\Programs\Python\Python39\Lib\comodo'
> from comodo.comodo import *

Open a notebook dove vuoi, stai comodo.
